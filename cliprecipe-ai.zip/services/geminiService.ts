import { GoogleGenAI, Type, Schema } from "@google/genai";
import { Recipe } from "../types";

// Initialize the API client
// Note: In a real production app, backend calls should proxy this to keep the key secret.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const recipeSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    title: { type: Type.STRING, description: "Nom de la recette" },
    description: { type: Type.STRING, description: "Brève description appétissante" },
    ingredients: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          item: { type: Type.STRING, description: "Nom de l'ingrédient" },
          quantity: { type: Type.STRING, description: "Quantité (ex: 200, 1/2)" },
          unit: { type: Type.STRING, description: "Unité (ex: g, ml, tasse)" },
        },
        required: ["item", "quantity"],
      },
    },
    steps: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          stepNumber: { type: Type.INTEGER },
          instruction: { type: Type.STRING, description: "Action précise à effectuer" },
          time: { type: Type.STRING, description: "Durée estimée de l'étape si applicable" },
        },
        required: ["stepNumber", "instruction"],
      },
    },
    prepTime: { type: Type.STRING, description: "Temps de préparation total" },
    cookTime: { type: Type.STRING, description: "Temps de cuisson total" },
    servings: { type: Type.STRING, description: "Nombre de portions" },
    tags: { type: Type.ARRAY, items: { type: Type.STRING }, description: "Mots clés (ex: Vegan, Italien, Dessert)" },
  },
  required: ["title", "ingredients", "steps", "prepTime", "cookTime", "servings"],
};

export const analyzeMediaAndGenerateRecipe = async (
  base64Images: string[]
): Promise<Partial<Recipe>> => {
  try {
    const parts = base64Images.map((img) => ({
      inlineData: {
        mimeType: "image/jpeg",
        data: img,
      },
    }));

    // Add the prompt as the last part
    const prompt = {
      text: `Analyse ces images (qui peuvent être des images individuelles ou des trames extraites d'une vidéo de cuisine).
      Identifie le plat en préparation.
      Extrais une recette structurée complète.
      Sois précis sur les quantités estimées visuellement si elles ne sont pas mentionnées.
      Réponds en français.`,
    };

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview", // Efficient for multimodal tasks
      contents: {
        parts: [...parts, prompt],
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: recipeSchema,
        systemInstruction: "Tu es un chef expert capable de déduire des recettes précises à partir de vidéos ou photos de cuisine.",
      },
    });

    const jsonText = response.text;
    if (!jsonText) throw new Error("No response from AI");

    return JSON.parse(jsonText);
  } catch (error) {
    console.error("Error generating recipe:", error);
    throw error;
  }
};
