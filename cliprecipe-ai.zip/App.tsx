import React, { useState, useEffect } from 'react';
import { ChefHat, LayoutGrid, PlusCircle, LogOut, User as UserIcon, Printer, X, CheckCircle2, CheckSquare } from 'lucide-react';
import { ViewState, User, Recipe } from './types';
import { RecipeGenerator } from './components/RecipeGenerator';
import { RecipeCard } from './components/RecipeCard';

// Mock database in LocalStorage
const RECIPES_KEY = 'cliprecipe_recipes';
const USER_KEY = 'cliprecipe_user';

export default function App() {
  const [view, setView] = useState<ViewState>(ViewState.LANDING);
  const [user, setUser] = useState<User | null>(null);
  const [currentRecipe, setCurrentRecipe] = useState<Recipe | null>(null);
  const [savedRecipes, setSavedRecipes] = useState<Recipe[]>([]);
  const [selectedRecipeIds, setSelectedRecipeIds] = useState<Set<string>>(new Set());

  // Load data on mount
  useEffect(() => {
    const storedUser = localStorage.getItem(USER_KEY);
    if (storedUser) {
      setUser(JSON.parse(storedUser));
      setView(ViewState.DASHBOARD);
    }
    
    const storedRecipes = localStorage.getItem(RECIPES_KEY);
    if (storedRecipes) {
      setSavedRecipes(JSON.parse(storedRecipes));
    }
  }, []);

  const handleLogin = () => {
    // Mock login
    const mockUser: User = {
      id: '1',
      name: 'Chef Amateur',
      email: 'user@example.com',
      savedRecipes: []
    };
    setUser(mockUser);
    localStorage.setItem(USER_KEY, JSON.stringify(mockUser));
    setView(ViewState.DASHBOARD);
  };

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem(USER_KEY);
    setView(ViewState.LANDING);
    setSelectedRecipeIds(new Set());
  };

  const saveRecipe = () => {
    if (!currentRecipe) return;
    
    const exists = savedRecipes.find(r => r.id === currentRecipe.id);
    if (!exists) {
      const updatedRecipes = [currentRecipe, ...savedRecipes];
      setSavedRecipes(updatedRecipes);
      localStorage.setItem(RECIPES_KEY, JSON.stringify(updatedRecipes));
      alert("Recette sauvegardée dans votre livre de cuisine !");
    }
  };

  const handleGenerated = (recipe: Recipe) => {
    setCurrentRecipe(recipe);
    setView(ViewState.RECIPE_DETAILS);
  };

  const toggleSelection = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const newSelection = new Set(selectedRecipeIds);
    if (newSelection.has(id)) {
      newSelection.delete(id);
    } else {
      newSelection.add(id);
    }
    setSelectedRecipeIds(newSelection);
  };

  const toggleSelectAll = () => {
    if (selectedRecipeIds.size === savedRecipes.length) {
      setSelectedRecipeIds(new Set());
    } else {
      setSelectedRecipeIds(new Set(savedRecipes.map(r => r.id)));
    }
  };

  const handleBulkExport = () => {
    setView(ViewState.PRINT_PREVIEW);
  };

  const clearSelection = () => {
    setSelectedRecipeIds(new Set());
  };

  const renderContent = () => {
    switch (view) {
      case ViewState.LANDING:
        return (
          <div className="flex flex-col items-center justify-center min-h-[80vh] text-center px-4">
            <div className="bg-brand-100 p-6 rounded-full mb-8 animate-bounce">
              <ChefHat size={64} className="text-brand-600" />
            </div>
            <h1 className="text-5xl md:text-6xl font-extrabold text-gray-900 mb-6 tracking-tight">
              Clip<span className="text-brand-600">Recipe</span>
            </h1>
            <p className="text-xl md:text-2xl text-gray-600 max-w-2xl mb-10 leading-relaxed">
              Transformez n'importe quelle vidéo de cuisine en recette détaillée en une seconde grâce à l'intelligence artificielle.
            </p>
            <button 
              onClick={handleLogin}
              className="bg-brand-600 hover:bg-brand-700 text-white text-lg font-bold py-4 px-10 rounded-full shadow-xl shadow-brand-500/30 transition-all transform hover:scale-105"
            >
              Commencer l'expérience
            </button>
          </div>
        );

      case ViewState.DASHBOARD:
        return (
          <div className="max-w-6xl mx-auto p-6 pb-24 relative">
            <div className="flex flex-col md:flex-row justify-between items-end md:items-center mb-8 gap-4">
              <div>
                <h2 className="text-3xl font-bold text-gray-900">Mon Livre de Cuisine</h2>
                <div className="flex items-center gap-2 text-gray-500 mt-1">
                  <span>{savedRecipes.length} recettes</span>
                  {savedRecipes.length > 0 && (
                    <>
                      <span>•</span>
                      <button 
                        onClick={toggleSelectAll}
                        className="text-brand-600 hover:text-brand-700 font-medium text-sm flex items-center gap-1"
                      >
                         <CheckSquare size={14} />
                        {selectedRecipeIds.size === savedRecipes.length ? 'Tout désélectionner' : 'Tout sélectionner'}
                      </button>
                    </>
                  )}
                </div>
              </div>
              <button 
                onClick={() => setView(ViewState.CREATE)}
                className="bg-brand-600 text-white px-6 py-2 rounded-lg font-bold flex items-center gap-2 hover:bg-brand-700 transition"
              >
                <PlusCircle size={20} />
                Nouvelle Recette
              </button>
            </div>

            {savedRecipes.length === 0 ? (
              <div className="text-center py-20 bg-gray-50 rounded-2xl border-2 border-dashed border-gray-200">
                <p className="text-gray-400 text-lg">Aucune recette sauvegardée.</p>
                <button 
                  onClick={() => setView(ViewState.CREATE)}
                  className="mt-4 text-brand-600 font-bold hover:underline"
                >
                  Créez votre première recette
                </button>
              </div>
            ) : (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {savedRecipes.map(recipe => {
                  const isSelected = selectedRecipeIds.has(recipe.id);
                  return (
                    <div 
                      key={recipe.id} 
                      className={`bg-white rounded-xl shadow transition overflow-hidden border flex flex-col relative group cursor-pointer ${isSelected ? 'ring-2 ring-brand-500 border-transparent' : 'border-gray-100 hover:shadow-lg'}`}
                      onClick={() => { setCurrentRecipe(recipe); setView(ViewState.RECIPE_DETAILS); }}
                    >
                      {/* Checkbox Overlay */}
                      <div 
                        className="absolute top-3 left-3 z-10 p-1"
                        onClick={(e) => toggleSelection(recipe.id, e)}
                      >
                         <div className={`w-8 h-8 rounded-full border-2 flex items-center justify-center transition-all shadow-sm ${isSelected ? 'bg-brand-500 border-brand-500 scale-110' : 'bg-white/90 border-gray-300 hover:border-brand-400 text-transparent hover:text-gray-200'}`}>
                            {isSelected ? <CheckCircle2 size={18} className="text-white" /> : <div className="w-4 h-4 rounded-full bg-transparent" />}
                         </div>
                      </div>

                      <div className="h-48 bg-gray-200 overflow-hidden relative">
                         {/* Placeholder or real image */}
                         <div className="absolute inset-0 bg-brand-50 flex items-center justify-center text-brand-200">
                            <ChefHat size={48} />
                         </div>
                      </div>
                      <div className="p-5 flex-1 flex flex-col">
                        <h3 className="text-xl font-bold text-gray-800 mb-2">{recipe.title}</h3>
                        <p className="text-gray-500 text-sm line-clamp-2 mb-4 flex-1">{recipe.description}</p>
                        <div className="flex justify-between items-center text-sm text-gray-400 mt-auto">
                          <span>{recipe.prepTime}</span>
                          <span className="text-brand-600 font-bold hover:text-brand-700">
                            Voir la recette →
                          </span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            {/* Floating Action Bar */}
            {selectedRecipeIds.size > 0 && (
              <div className="fixed bottom-6 left-1/2 transform -translate-x-1/2 bg-gray-900 text-white px-6 py-4 rounded-full shadow-2xl flex items-center gap-6 z-50 animate-in fade-in slide-in-from-bottom-4">
                <span className="font-medium text-gray-300">{selectedRecipeIds.size} sélectionnée(s)</span>
                <div className="h-6 w-px bg-gray-700"></div>
                <button 
                  onClick={handleBulkExport}
                  className="flex items-center gap-2 font-bold hover:text-brand-400 transition"
                >
                  <Printer size={20} />
                  Exporter en PDF
                </button>
                <button 
                  onClick={clearSelection}
                  className="flex items-center gap-2 text-gray-400 hover:text-white transition"
                >
                  <X size={20} />
                </button>
              </div>
            )}
          </div>
        );

      case ViewState.CREATE:
        return (
          <div className="max-w-4xl mx-auto pt-10">
            <div className="text-center mb-10">
               <h2 className="text-3xl font-bold text-gray-900">Nouvelle Analyse</h2>
               <p className="text-gray-500 mt-2">L'IA va regarder votre vidéo et écrire la recette pour vous.</p>
            </div>
            <RecipeGenerator onRecipeGenerated={handleGenerated} />
            <div className="mt-8 text-center">
              <button 
                onClick={() => setView(ViewState.DASHBOARD)}
                className="text-gray-400 hover:text-gray-600 underline"
              >
                Annuler
              </button>
            </div>
          </div>
        );

      case ViewState.RECIPE_DETAILS:
        return currentRecipe ? (
          <div className="pb-20">
            <div className="max-w-4xl mx-auto px-4 py-4">
              <button 
                onClick={() => setView(ViewState.DASHBOARD)} 
                className="text-gray-500 hover:text-gray-800 font-medium mb-4 flex items-center gap-2"
              >
                ← Retour au tableau de bord
              </button>
            </div>
            <RecipeCard 
              recipe={currentRecipe} 
              onSave={saveRecipe} 
              isSaved={savedRecipes.some(r => r.id === currentRecipe?.id)}
            />
          </div>
        ) : null;

      case ViewState.PRINT_PREVIEW:
        const selectedRecipes = savedRecipes.filter(r => selectedRecipeIds.has(r.id));
        return (
          <div className="min-h-screen bg-gray-100 print:bg-white">
             {/* Header - Hidden on print */}
             <div className="bg-gray-900 text-white py-4 px-6 shadow-lg sticky top-0 z-50 flex justify-between items-center print:hidden">
                <div className="flex items-center gap-4">
                  <button 
                    onClick={() => setView(ViewState.DASHBOARD)}
                    className="p-2 hover:bg-white/10 rounded-full transition"
                  >
                    <X size={24} />
                  </button>
                  <span className="font-bold text-lg">Aperçu de l'export ({selectedRecipes.length} recettes)</span>
                </div>
                <button 
                  onClick={() => window.print()}
                  className="bg-brand-600 hover:bg-brand-700 text-white px-6 py-2 rounded-lg font-bold flex items-center gap-2 transition"
                >
                  <Printer size={20} />
                  Imprimer / Sauvegarder en PDF
                </button>
             </div>

             {/* Content */}
             <div className="max-w-4xl mx-auto p-8 print:p-0 print:w-full print:max-w-none">
                <style>{`
                  @media print {
                    @page { margin: 1cm; size: auto; }
                    body { -webkit-print-color-adjust: exact; }
                    .print-break { break-after: page; page-break-after: always; }
                    /* Ensure headers don't detach from content */
                    h1, h2, h3 { break-after: avoid; page-break-after: avoid; }
                  }
                `}</style>
                
                {selectedRecipes.map((recipe, index) => (
                  <div key={recipe.id} className="mb-8 print:mb-0">
                    <RecipeCard recipe={recipe} hideActions={true} />
                    {index < selectedRecipes.length - 1 && (
                      <div className="print-break w-full h-8 print:h-0"></div>
                    )}
                  </div>
                ))}
             </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className={`min-h-screen bg-white font-sans text-gray-900 ${view === ViewState.PRINT_PREVIEW ? '' : ''}`}>
      {/* Navigation - Hidden in print mode */}
      {view !== ViewState.PRINT_PREVIEW && (
        <nav className="border-b border-gray-100 sticky top-0 bg-white/80 backdrop-blur-md z-50 print:hidden">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
            <div 
              className="flex items-center gap-2 cursor-pointer" 
              onClick={() => setView(user ? ViewState.DASHBOARD : ViewState.LANDING)}
            >
              <ChefHat className="text-brand-600" size={28} />
              <span className="text-xl font-bold tracking-tight">Clip<span className="text-brand-600">Recipe</span></span>
            </div>

            <div className="flex items-center gap-4">
              {user ? (
                <>
                  <button 
                    onClick={() => setView(ViewState.DASHBOARD)}
                    className={`p-2 rounded-full transition ${view === ViewState.DASHBOARD ? 'bg-brand-50 text-brand-600' : 'text-gray-500 hover:bg-gray-100'}`}
                  >
                    <LayoutGrid size={20} />
                  </button>
                  <div className="h-6 w-px bg-gray-200"></div>
                  <div className="flex items-center gap-3">
                    <div className="text-right hidden sm:block">
                      <p className="text-sm font-bold text-gray-900">{user.name}</p>
                      <p className="text-xs text-gray-500">Chef Level 1</p>
                    </div>
                    <div className="w-10 h-10 bg-brand-100 rounded-full flex items-center justify-center text-brand-700 font-bold border-2 border-white shadow-sm">
                      {user.name.charAt(0)}
                    </div>
                    <button 
                      onClick={handleLogout}
                      className="ml-2 text-gray-400 hover:text-red-500 transition"
                      title="Déconnexion"
                    >
                      <LogOut size={20} />
                    </button>
                  </div>
                </>
              ) : (
                view !== ViewState.LANDING && (
                  <button 
                    onClick={handleLogin}
                    className="text-sm font-bold text-gray-700 hover:text-brand-600"
                  >
                    Connexion
                  </button>
                )
              )}
            </div>
          </div>
        </nav>
      )}

      <main>
        {renderContent()}
      </main>
    </div>
  );
}
