export interface Ingredient {
  item: string;
  quantity: string;
  unit?: string;
}

export interface Step {
  stepNumber: number;
  instruction: string;
  time?: string;
}

export interface Recipe {
  id: string;
  title: string;
  description: string;
  ingredients: Ingredient[];
  steps: Step[];
  prepTime: string;
  cookTime: string;
  servings: string;
  tags: string[];
  imageUrl?: string;
  createdAt: number;
}

export interface User {
  id: string;
  name: string;
  email: string;
  savedRecipes: string[]; // ID of saved recipes
}

export enum ViewState {
  LANDING = 'LANDING',
  LOGIN = 'LOGIN',
  DASHBOARD = 'DASHBOARD',
  CREATE = 'CREATE',
  RECIPE_DETAILS = 'RECIPE_DETAILS',
  PRINT_PREVIEW = 'PRINT_PREVIEW'
}
