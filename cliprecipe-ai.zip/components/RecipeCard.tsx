import React from 'react';
import { Recipe } from '../types';
import { Clock, Users, ChefHat, Save, Share2, Printer } from 'lucide-react';

interface RecipeCardProps {
  recipe: Recipe;
  onSave?: () => void;
  isSaved?: boolean;
  hideActions?: boolean;
}

export const RecipeCard: React.FC<RecipeCardProps> = ({ recipe, onSave, isSaved = false, hideActions = false }) => {
  const handlePrint = () => {
    window.print();
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: recipe.title,
          text: `Découvre cette recette de ${recipe.title} sur ClipRecipe !`,
          url: window.location.href,
        });
      } catch (err) {
        console.log('Error sharing', err);
      }
    } else {
      alert('Partage non supporté sur ce navigateur');
    }
  };

  return (
    <div className="bg-white rounded-2xl shadow-xl overflow-hidden max-w-4xl mx-auto my-8 border border-gray-100 print:shadow-none print:border-none print:my-0 print:mb-8">
      <div className="bg-brand-500 p-6 text-white relative print:bg-white print:text-black print:border-b-2 print:border-black print:px-0">
        <h1 className="text-3xl font-bold mb-2">{recipe.title}</h1>
        <p className="opacity-90 print:text-gray-600">{recipe.description}</p>
        
        <div className="flex flex-wrap gap-4 mt-6 text-sm font-medium print:mt-4">
          <div className="flex items-center gap-2 bg-white/20 px-3 py-1 rounded-full backdrop-blur-sm print:bg-gray-100 print:text-black print:border">
            <Clock size={18} />
            <span>Prép: {recipe.prepTime}</span>
          </div>
          <div className="flex items-center gap-2 bg-white/20 px-3 py-1 rounded-full backdrop-blur-sm print:bg-gray-100 print:text-black print:border">
            <ChefHat size={18} />
            <span>Cuisson: {recipe.cookTime}</span>
          </div>
          <div className="flex items-center gap-2 bg-white/20 px-3 py-1 rounded-full backdrop-blur-sm print:bg-gray-100 print:text-black print:border">
            <Users size={18} />
            <span>{recipe.servings} portions</span>
          </div>
        </div>

        {!hideActions && (
          <div className="absolute top-6 right-6 flex gap-2 print:hidden">
            <button 
              onClick={onSave}
              className={`p-2 rounded-full backdrop-blur-md transition ${isSaved ? 'bg-white text-brand-500' : 'bg-black/20 text-white hover:bg-black/30'}`}
            >
              <Save size={20} fill={isSaved ? "currentColor" : "none"} />
            </button>
            <button onClick={handleShare} className="p-2 rounded-full bg-black/20 text-white hover:bg-black/30 backdrop-blur-md transition">
              <Share2 size={20} />
            </button>
            <button onClick={handlePrint} className="p-2 rounded-full bg-black/20 text-white hover:bg-black/30 backdrop-blur-md transition">
              <Printer size={20} />
            </button>
          </div>
        )}
      </div>

      <div className="grid md:grid-cols-3 gap-8 p-8 print:px-0 print:gap-4 print:block">
        {/* Ingredients Column */}
        <div className="md:col-span-1 space-y-6 print:mb-6">
          <h3 className="text-xl font-bold text-gray-800 border-b-2 border-brand-100 pb-2 print:border-black">Ingrédients</h3>
          <ul className="space-y-3 print:grid print:grid-cols-2 print:gap-2 print:space-y-0">
            {recipe.ingredients.map((ing, idx) => (
              <li key={idx} className="flex items-start gap-3 text-gray-700 bg-brand-50 p-3 rounded-lg print:bg-transparent print:p-0 print:border-b print:border-gray-100">
                <div className="h-2 w-2 rounded-full bg-brand-500 mt-2 shrink-0 print:hidden" />
                <span>
                  <span className="font-bold text-gray-900">{ing.quantity} {ing.unit}</span> {ing.item}
                </span>
              </li>
            ))}
          </ul>
        </div>

        {/* Instructions Column */}
        <div className="md:col-span-2 space-y-6">
          <h3 className="text-xl font-bold text-gray-800 border-b-2 border-brand-100 pb-2 print:border-black">Instructions</h3>
          <div className="space-y-6">
            {recipe.steps.map((step, idx) => (
              <div key={idx} className="flex gap-4 print:break-inside-avoid">
                <div className="flex-shrink-0 w-8 h-8 rounded-full bg-brand-100 text-brand-600 flex items-center justify-center font-bold print:border print:border-gray-300 print:bg-white print:text-black">
                  {step.stepNumber}
                </div>
                <div className="pt-1">
                  <p className="text-gray-700 leading-relaxed text-lg print:text-black">{step.instruction}</p>
                  {step.time && (
                    <span className="text-sm text-brand-600 font-medium mt-1 inline-block print:text-gray-600">
                      ⏱ {step.time}
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
      
      {recipe.tags && (
        <div className="px-8 pb-8 flex gap-2 flex-wrap print:hidden">
          {recipe.tags.map(tag => (
            <span key={tag} className="text-xs font-medium text-gray-500 bg-gray-100 px-2 py-1 rounded">
              #{tag}
            </span>
          ))}
        </div>
      )}
    </div>
  );
};
