import React, { useState, useRef, useCallback } from 'react';
import { Upload, Camera, Film, Loader2, PlayCircle } from 'lucide-react';
import { analyzeMediaAndGenerateRecipe } from '../services/geminiService';
import { Recipe } from '../types';

interface RecipeGeneratorProps {
  onRecipeGenerated: (recipe: Recipe) => void;
}

export const RecipeGenerator: React.FC<RecipeGeneratorProps> = ({ onRecipeGenerated }) => {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [statusText, setStatusText] = useState('');
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [mediaType, setMediaType] = useState<'video' | 'image' | null>(null);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);

  // Helper to extract frames from a video file
  const extractFrames = async (videoUrl: string): Promise<string[]> => {
    return new Promise((resolve) => {
      const video = document.createElement('video');
      video.src = videoUrl;
      video.muted = true;
      video.crossOrigin = "anonymous";
      
      const frames: string[] = [];
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');

      video.onloadedmetadata = async () => {
        canvas.width = video.videoWidth; // Reduce scale if needed for performance
        canvas.height = video.videoHeight;
        
        const duration = video.duration;
        // Extract 5 frames evenly distributed
        const count = 5;
        const interval = duration / (count + 1);

        const seekAndCapture = async (index: number) => {
          if (index >= count) {
             resolve(frames);
             return;
          }
          
          const time = interval * (index + 1);
          video.currentTime = time;
        };

        video.onseeked = () => {
          if (ctx) {
            ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
            // Compress quality to 0.6 to save tokens/bandwidth
            frames.push(canvas.toDataURL('image/jpeg', 0.6).split(',')[1]); 
          }
          seekAndCapture(frames.length);
        };

        seekAndCapture(0);
      };
      
      video.load(); // Trigger load
    });
  };

  const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const objectUrl = URL.createObjectURL(file);
    setPreviewUrl(objectUrl);
    setIsAnalyzing(true);

    try {
      let base64Images: string[] = [];

      if (file.type.startsWith('video/')) {
        setMediaType('video');
        setStatusText('Découpage de la vidéo en clips (extraction de frames)...');
        base64Images = await extractFrames(objectUrl);
      } else if (file.type.startsWith('image/')) {
        setMediaType('image');
        setStatusText('Traitement de l\'image...');
        // Convert single image to base64
        const reader = new FileReader();
        const base64Promise = new Promise<string>((resolve) => {
            reader.onload = (e) => resolve((e.target?.result as string).split(',')[1]);
        });
        reader.readAsDataURL(file);
        base64Images = [await base64Promise];
      }

      setStatusText('Analyse IA avec Gemini Vision...');
      
      const generatedData = await analyzeMediaAndGenerateRecipe(base64Images);

      // Add Metadata
      const completeRecipe: Recipe = {
        ...generatedData as Recipe, // Type assertion for simplicity
        id: crypto.randomUUID(),
        createdAt: Date.now(),
        imageUrl: objectUrl // Use the blob URL for display temporarily
      };

      onRecipeGenerated(completeRecipe);

    } catch (error) {
      console.error(error);
      alert("Une erreur est survenue lors de l'analyse.");
      setIsAnalyzing(false);
      setPreviewUrl(null);
    }
  };

  return (
    <div className="w-full max-w-2xl mx-auto p-6">
      {!isAnalyzing && !previewUrl ? (
        <div className="border-4 border-dashed border-gray-200 rounded-3xl p-10 text-center hover:border-brand-300 transition-colors bg-white/50 backdrop-blur-sm">
          <div className="bg-brand-100 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6 text-brand-600">
            <Camera size={40} />
          </div>
          <h2 className="text-2xl font-bold text-gray-800 mb-2">Analysez votre plat</h2>
          <p className="text-gray-500 mb-8">
            Importez une vidéo de recette ou une photo de plat. <br/>
            L'IA identifiera les ingrédients et les étapes.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button 
              onClick={() => fileInputRef.current?.click()}
              className="bg-brand-600 text-white px-8 py-4 rounded-xl font-bold shadow-lg shadow-brand-500/30 hover:bg-brand-700 transition flex items-center justify-center gap-3"
            >
              <Upload size={20} />
              Choisir un fichier
            </button>
            {/* <button className="bg-white text-gray-700 px-8 py-4 rounded-xl font-bold shadow border border-gray-200 hover:bg-gray-50 transition flex items-center justify-center gap-3">
               <Camera size={20} />
               Prendre photo
            </button> */}
          </div>
          <input 
            type="file" 
            ref={fileInputRef} 
            onChange={handleFileChange} 
            accept="image/*,video/*" 
            className="hidden" 
          />
        </div>
      ) : (
        <div className="bg-white rounded-2xl shadow-xl p-8 text-center">
          {previewUrl && mediaType === 'video' && (
             <video ref={videoRef} src={previewUrl} className="w-full h-48 object-cover rounded-xl mb-6 bg-black" controls />
          )}
          {previewUrl && mediaType === 'image' && (
             <img src={previewUrl} alt="Preview" className="w-full h-48 object-cover rounded-xl mb-6" />
          )}

          {isAnalyzing && (
            <div className="space-y-4">
               <Loader2 className="animate-spin mx-auto text-brand-500" size={48} />
               <p className="text-lg font-medium text-gray-700 animate-pulse">{statusText}</p>
               <p className="text-sm text-gray-400">Cela peut prendre quelques secondes...</p>
            </div>
          )}
        </div>
      )}
      
      {/* Demo helper */}
      <div className="mt-8 text-center">
        <p className="text-xs text-gray-400 uppercase tracking-wider font-semibold">Propulsé par Gemini 2.5 Flash Multimodal</p>
      </div>
    </div>
  );
};
